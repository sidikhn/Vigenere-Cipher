# Tugas kriptografi

Kelompok 2

### Preview

|                                                          |                                                          |
| -------------------------------------------------------- | -------------------------------------------------------- |
| Landing Page                                             | Encryption Page                                          |
| ![Landing Page](assets/github-preview/home.png)          | ![Encryption Page](assets/github-preview/encryption.png) |
| Decryption Page                                          |                                                          |
| ![Decryption Page](assets/github-preview/decryption.png) |                                                          |
