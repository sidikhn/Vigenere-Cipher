<?php include '../encryption/vignere.php' ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="apple-touch-icon" sizes="180x180" href="../assets/icon/apple-touch-icon.png" />
  <link rel="icon" type="image/png" sizes="32x32" href="../assets/icon/32x32.png" />
  <link rel="icon" type="image/png" sizes="16x16" href="../assets/icon/16x16.png" />
  <link rel="manifest" href="../assets/icon/site.webmanifest" />
  <title>Vigenère Cipher | Hikmah Nursidik</title>
  <link href="https://fonts.googleapis.com/css2?family=Passero+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/styles.css">
  
</head>

<body>
  <header>
    <h1>Encrypt Text</h1>
    <h2>Translate any text message into a secret.</h2>
    <span class="btngroup">
    <button class="btngroup--btn" onclick="window.location='../index.html';">Home</button>
      <button class="btngroup--btn">Encrypt Text</button>
      <button class="btngroup--btn" onclick="window.location='decrypt_view.php';">Decrypt Text</button>
    </span>
  </header>

  <main>
    <form action="" method="post">
      <fieldset>
        <legend>Text to Encrypt</legend>
        <textarea id="input-text" name="plaintext" rows="10" cols="60" placeholder="Enter your message to encrypted here"><?= isset($encodedCipher) ? $encodedCipher : ''; ?></textarea>
      </fieldset>
      <fieldset>
        <legend>Key</legend>
        <input type="text" name="key" placeholder="Enter your key here" value="<?= isset($key) ? $key : ''; ?>">
      </fieldset>
      <fieldset>
        <hr>
          <div class="btn-container">
            <input type="submit" name="btn-encrypt" class="btn-encrypt" value="Encrypt It!">
            <input type="submit" name="btn-reset" id="btn-reset" class="btn-reset" value="Clear">
          </div>
        <hr>
      </fieldset>
    </form>


    <div id="result-area" >
     <h3>Result:</h3>
      <pre><code class="language-html"><?php echo (isset($encodedCipher) ? $encodedCipher : 'No text encrypted'); ?></code></pre>
    </div>
  </main>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
        var inputText = document.getElementById('input-text');
        var btnReset = document.getElementById('btn-reset');

        // Fungsi untuk menampilkan atau menyembunyikan tombol "Clear"
        function toggleClearButton() {
            btnReset.style.display = inputText.value.trim() !== '' ? 'block' : 'none';
        }

        // Panggil fungsi saat halaman dimuat dan saat nilai textarea berubah
        toggleClearButton();
        inputText.addEventListener('input', toggleClearButton);
    });
    </script>


  <script src="../assets/js/scripts.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.26.0/prism.min.js"></script>
</body>

</html>