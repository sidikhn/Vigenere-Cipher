<?php
// Fungsi untuk melakukan enkripsi menggunakan Vigenere Cipher
function vigenereEncrypt($plaintext, $key)
{
    $plaintext = strtoupper($plaintext);
    $key = strtoupper($key);

    $result = '';
    $keyLength = strlen($key);

    for ($i = 0, $j = 0; $i < strlen($plaintext); $i++) {
        $char = $plaintext[$i];

        // Cek apakah karakter merupakan huruf
        if (ctype_alpha($char)) {
            // Ubah karakter plaintext dan key menjadi angka (A=0, B=1, ..., Z=25)
            $charIndex = ord($char) - ord('A');
            $keyIndex = ord($key[$j % $keyLength]) - ord('A');

            // Hitung karakter enkripsi menggunakan rumus Vigenere
            $encryptedChar = chr(((($charIndex + $keyIndex) % 26) + ord('A')));

            // Tambahkan karakter enkripsi ke hasil
            $result .= $encryptedChar;

            // Pindah ke karakter berikutnya pada key
            $j++;
        } else {
            // Tambahkan karakter non-huruf tanpa enkripsi
            $result .= $char;
        }
    }

    return $result;
}

// Fungsi untuk melakukan dekripsi menggunakan Vigenere Cipher
function vigenereDecrypt($ciphertext, $key)
{
    $ciphertext = strtoupper($ciphertext);
    $key = strtoupper($key);

    $result = '';
    $keyLength = strlen($key);

    for ($i = 0, $j = 0; $i < strlen($ciphertext); $i++) {
        $char = $ciphertext[$i];

        // Cek apakah karakter merupakan huruf
        if (ctype_alpha($char)) {
            // Ubah karakter ciphertext dan key menjadi angka (A=0, B=1, ..., Z=25)
            $charIndex = ord($char) - ord('A');
            $keyIndex = ord($key[$j % $keyLength]) - ord('A');

            // Hitung karakter dekripsi menggunakan rumus Vigenere
            $decryptedChar = chr(((($charIndex - $keyIndex + 26) % 26) + ord('A')));

            // Tambahkan karakter dekripsi ke hasil
            $result .= $decryptedChar;

            // Pindah ke karakter berikutnya pada key
            $j++;
        } else {
            // Tambahkan karakter non-huruf tanpa dekripsi
            $result .= $char;
        }
    }

    return $result;
}

// NOTE: Proses enkripsi jika tombol encrypt diklik
if (isset($_POST['btn-encrypt'])) {
    $plaintext = $_POST['plaintext'];
    $key = $_POST['key'];
    if ($plaintext != '' && $key != '') {
        $encodedCipher = vigenereEncrypt($plaintext, $key);
    } else {
        $encodedCipher = 'Plaintext & Key is required';
    }
}



// NOTE: Proses dekripsi jika tombol decrypt diklik
if (isset($_POST['btn-decrypt'])) {
    $encodedCipher = $_POST['ciphertext'];
    $key = $_POST['key'];
    if ($encodedCipher != '' && $key != '') {
        $decrypted = vigenereDecrypt($encodedCipher, $key);
    } else {
        $decrypted = 'Ciphertext & Key is required';
    }
}

// NOTE: Reset nilai
if (isset($_POST['btn-reset'])) {
    $encodedCipher = '';
    $decrypted = '';
}
?>
